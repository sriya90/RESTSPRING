package com.powerreviews.project.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface ReviewRepository extends CrudRepository<ReviewEntity, Integer>{

    @Query(value = "SELECT r FROM review r WHERE resId =:resId order by reviewDate desc", nativeQuery = false)
    List<ReviewEntity> getReviews(@Param("resId")Integer resId);

}

