package com.powerreviews.project.persistence;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name = "review")
public class ReviewEntity
{
    @Id
    @GeneratedValue
    @Column(name = "id", updatable = false, nullable = false)
    private Integer id;

    @Column
    private Integer resId;

    @Column
    private String userId;

    @Column
    private String review;

    @Column
    private Date reviewDate;

    public Date getReviewDate()
    {
        return reviewDate;
    }

    public void setReviewDate(Date reviewDate)
    {
        this.reviewDate = reviewDate;
    }

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getResId()
    {
        return resId;
    }

    public void setResId(Integer resId)
    {
        this.resId = resId;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getReview()
    {
        return review;
    }

    public void setReview(String review)
    {
        this.review = review;
    }

    public ReviewEntity(){}

    public ReviewEntity(Integer id, Integer resId, String userId, String review, Date reviewDate)
    {
        this.id = id;
        this.resId = resId;
        this.userId = userId;
        this.review = review;
        this.reviewDate = reviewDate;
    }
}
